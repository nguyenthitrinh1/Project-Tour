import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [role, setRole] = useState(''); // Vai trò: admin hoặc customer
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    if (role === 'admin' || role === 'customer') {
      // Lưu vai trò vào localStorage để test
      localStorage.setItem('role', role);
      // Chuyển hướng dựa trên vai trò
      navigate(role === 'admin' ? '/admin' : '/customer');
    } else {
      alert('Vui lòng chọn vai trò hợp lệ (admin hoặc customer)');
    }
  };

  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h2>Đăng nhập (Test)</h2>
      <form onSubmit={handleLogin}>
        <label>
          Chọn vai trò:
          <select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="">-- Chọn --</option>
            <option value="admin">Admin</option>
            <option value="customer">Customer</option>
          </select>
        </label>
        <br />
        <button type="submit" style={{ marginTop: '10px' }}>
          Đăng nhập
        </button>
      </form>
    </div>
  );
};

export default Login;