export default function StructureCustomer(){
    return(
        <text>Announ</text>
    );
}