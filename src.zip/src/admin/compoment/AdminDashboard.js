import './App.css';
import { Routes, Route } from "react-router-dom";
import Header from '../compoment/Header/index.js';
import MainLayout from '../compoment/Main-layot/index.js';
//import TabNavigation from './compoment/Sidebar/index.js';
import Overview from '../compoment/Main/index';
import Tour from "../compoment/Tour/index";
import Trip from '../compoment/Trip/index'
import Announ from '../compoment/Announ/Announ.js';
import Information from '../compoment/Information/index';
import Setting from '../compoment/Setting/index';

function AdminDashboard() {
  console.log('Rendering AdminDashboard');
  return (
    <div className='Main'>
      <Header />
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route path='/main' element={<Overview />} />
          <Route path='/tour' element={<Tour />} />
          <Route path='/trip' element={<Trip />} />
          <Route path="/announ" element={<Announ />} />
          <Route path="/information" element={<Information />} />
          <Route path="/setting" element={<Setting />} />
        </Route>
      </Routes>
    </div>
  );
}

export default AdminDashboard;
