import React, { useState } from 'react';
import './Setting.css';

import StructureTour from '../StructureTour/index';
import StructureTrip from '../StructureTrip/index';
import StructureInfor from '../StructureInfor/index';
import StructureCustomer from '../StructureCustomer/index';
import StructureAnnoun from '../StructureAnnoun/index';

const Setting = () => {
  const [activeTab, setActiveTab] = useState('tour'); 

  const tabs = [
    { id: 'tour', label: 'Tour', icon: '🛒', component: <StructureTour /> },
    { id: 'trip', label: 'Đơn hàng', icon: '✈️', component: <StructureTrip /> },
    { id: 'staff', label: 'Nhân viên', icon: '👤', component: <StructureInfor /> },
    { id: 'customer', label: 'Khách hàng', icon: '👥', component: <StructureCustomer /> },
    { id: 'announ', label: 'Thống báo', icon: '🔔', component: <StructureAnnoun /> },
  ];

  return (
    <div className="setting-container">
      <h2>Setting</h2>
      <h3>Cấu hình chung</h3>
      <div className="setting-tabs">
        {tabs.map((tab) => (
          <div
            key={tab.id}
            className={`setting-tab ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            <span className="tab-icon">{tab.icon}</span>
            <span>{tab.label}</span>
          </div>
        ))}
      </div>
      <div className="setting-content">
        {tabs.find((tab) => tab.id === activeTab)?.component}
      </div>
    </div>
  );
};

export default Setting;