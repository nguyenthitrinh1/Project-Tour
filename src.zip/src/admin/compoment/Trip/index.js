import React, { useState } from 'react';
import AddTrip from '../AddTrip/index';
import TripDetails from '../SetTour/index'; // Import TripDetails
import './Trip.css';

const Trip = () => {
  const [trips, setTrip] = useState([
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', Customer: 'Nguyen Thi Trinh', Side: 'Nguyen Thi Trinh' },
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', Customer: 'Nguyen Thi Trinh', Side: 'Nguyen Thi Trinh' },
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', Customer: 'Nguyen Thi Trinh', Side: 'Nguyen Thi Trinh' },
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', Customer: 'Nguyen Thi Trinh', Side: 'Nguyen Thi Trinh' },
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', Customer: 'Nguyen Thi Trinh', Side: 'Nguyen Thi Trinh' },
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', Customer: 'Nguyen Thi Trinh', Side: 'Nguyen Thi Trinh' },
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', Customer: 'Nguyen Thi Trinh', Side: 'Nguyen Thi Trinh' },
  ]);
  const [isModalTripOpen, setIsModalTripOpen] = useState(false);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('Tất cả');
  const [selectedTrip, setSelectedTrip] = useState(null); // State để lưu chuyến đi được chọn
  const [isDetailsOpen, setIsDetailsOpen] = useState(false); // State để kiểm soát hiển thị TripDetails

  const handleSearch = (e) => {
    const keyword = e.target.value;
    setSearchKeyword(keyword);
    // fetchTrips(keyword, selectedStatus);
  };

  const handleStatusChange = (status) => {
    setSelectedStatus(status);
    setSearchKeyword('');
    // fetchTrips('', status);
  };

  const openTripModal = () => {
    setIsModalTripOpen(true);
  };

  const closeTripModal = () => {
    setIsModalTripOpen(false);
  };

  const handleAddTrip = (newTrip) => {
    setTrip((prev) => [...prev, newTrip]);
    closeTripModal();
  };

  const handleExportExcel = () => {
    alert('Chức năng xuất Excel chưa được triển khai!');
  };

  const openTripDetails = (trip) => {
    setSelectedTrip(trip);
    setIsDetailsOpen(true);
  };

  const closeTripDetails = () => {
    setIsDetailsOpen(false);
    setSelectedTrip(null);
  };

  return (
    <div className="trip-container">
      <div className="trip-header">
        <img
          onClick={openTripModal}
          src="/Plus 01.png"
          alt=""
          className="trip-add"
        />

        <div className="trip-search">
          <text>Tìm kiếm</text>
          <input
            type="text"
            onChange={handleSearch} // Sửa onClick thành onChange để xử lý tìm kiếm
            placeholder="Mã đơn hàng\Tên khách hàng"
            className="trip-input"
          />
          <img src="/Plane.png" alt="" />
        </div>
        <div className="trip-refesh">
          <img src="/Refresh Circle.png" alt="" />
          <p>Tải lại</p>
        </div>
        <div className="trip-excel" onClick={handleExportExcel}>
          <img src="/Icon.png" alt="" />
          <p>Xuất Excel</p>
        </div>
      </div>
      <div className="trip-body">
        <div className="status-buttons">
          {['Tất cả', 'Chờ xử lý', 'Chờ đi', 'Đang hoạt động', 'Đã hoạt động'].map((status) => (
            <button
              key={status}
              className={`trip-button ${selectedStatus === status ? 'active' : ''}`}
              onClick={() => handleStatusChange(status)}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      <table className="trip-table">
        <thead>
          <tr>
            <th>
              <input type="checkbox" />
            </th>
            <th>Mã đặt tour</th>
            <th>Tên tour</th>
            <th>Tên khách hàng</th>
            <th>Phân công cho</th>
          </tr>
        </thead>
        <tbody>
          {trips.map((trip, index) => (
            <tr key={index} onClick={() => openTripDetails(trip)} style={{ cursor: 'pointer' }}>
              <td>
                <input type="checkbox" />
              </td>
              <td>{trip.id}</td>
              <td>{trip.name}</td>
              <td>{trip.Customer}</td>
              <td>{trip.Side}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {isModalTripOpen && <AddTrip onClose={closeTripModal} onAddTrip={handleAddTrip} />}
      {isDetailsOpen && <TripDetails trip={selectedTrip} onClose={closeTripDetails} />}
    </div>
  );
};

export default Trip;