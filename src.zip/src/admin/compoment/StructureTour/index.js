export default function StructureTour(){
    return(
        <text>Announ</text>
    );
}