import React, { useState } from 'react';
import AddTour from '../AddTour/index';
import "./tour.css"
const Tour = () => {
  const [tours, setTours] = useState([
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', image: '', type: 'Tour trong nước', vehicle: 'Ôtô' },
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', image: '', type: 'Tour trong nước', vehicle: 'Ôtô' },
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', image: '', type: 'Tour trong nước', vehicle: 'Ôtô' },
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', image: '', type: 'Tour trong nước', vehicle: 'Ôtô' },
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', image: '', type: 'Tour trong nước', vehicle: 'Ôtô' },
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', image: '', type: 'Tour trong nước', vehicle: 'Ôtô' },
    { id: 'Tour-1', name: 'HÀ NỘI - SAPA 4 NGÀY 3 ĐÊM', image: '', type: 'Tour trong nước', vehicle: 'Ôtô' },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const handleAddTour = (newTour) => {
    setTours((prev) => [...prev, newTour]);
    closeModal();
  };

  return (
    <div className="tour-container">
      <div className="tour-header">
        <img
          onClick={openModal}
          src="/Plus 01.png"
          alt=""
          className="tour-add"
        />


        <div className="tour-refesh">
          <img src="/Refresh Circle.png"
            alt=""
          />
          <text>Tải lại</text>
        </div>
        <div className="tour-search">
          <text>Tìm kiếm</text>
          <input
            type="text"
            placeholder="Mã/Tên tour/Phân loại"
            className="tour-input"
          />
          <img
            src="/Plane.png"
            alt=""
          />
        </div>
        <select
          name="type"
          className="tour-select"
          required
        >
          <option value="">Tất cả tour</option>
          <option value="Tour trong nước">Tour trong nước</option>
          <option value="Tour quốc tế">Tour quốc tế</option>
        </select>
      </div>

      <table className="tour-table">
        <thead>
          <tr>
            <th>Mã tour</th>
            <th>Tên tour</th>
            <th>Hình ảnh</th>
            <th>Loại tour</th>
            <th>Phương tiện</th>
          </tr>
        </thead>
        </table>
        <div className="tbody-content">
        <table className="tour-table">
        <tbody>
          {tours.map((tour, index) => (
            <tr key={index}>
              <td>{tour.id}</td>
              <td>{tour.name}</td>
              <td>
                {tour.image ? (
                  <img src={tour.image} alt="Tour" className="tour-image" />
                ) : (
                  <div className="tour-image-placeholder"></div>
                )}
              </td>
              <td>{tour.type}</td>
              <td>{tour.vehicle}</td>
            </tr>
          ))}
        </tbody>
        </table>
        </div>
      

      {isModalOpen && <AddTour onClose={closeModal} onAddTour={handleAddTour} />}
    </div>
  );
};

export default Tour;