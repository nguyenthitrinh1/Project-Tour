import React, { useState } from 'react';
import './AddTour.css';

const AddTour = ({ onClose, onAddTour }) => {
  const [newTour, setNewTour] = useState({
    id: '',
    name: '',
    price: '',
    discount: '',
    vehicle: '',
    type: '',
    area: '',
    payment: '',
    description: '',
    image: '',
    note: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewTour((prev) => ({ ...prev, [name]: value }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setNewTour((prev) => ({ ...prev, image: imageUrl }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onAddTour(newTour);
  };

  return (
    <div className="modal-tour_overlay">
      <div className="modal-tour_content">
        <div className="modal-tour_header">
          <h5>Thiết lập Tour</h5>
          <div className='modal-tour_header_group'>
          <img 
          src="/Eye Closed.png"
          alt=""
          />
          <div className='header-save'>
          <img 
          src="/Save 3.png"
          alt=""
          />
          <p>Lưu</p>
          </div>
          <button onClick={onClose} className="close-button">X</button>
          </div>
        </div>
        <div className="modal-tour_body">
        <form onSubmit={handleSubmit}>
          <div className="form-tour_row">
            <div className="form-tour_group">
              <label>Mã tour</label>
              <input
                type="text"
                name="id"
                placeholder='Mã Tour'
                value={newTour.id}
                onChange={handleInputChange}
                className="form-tour_input"
                required
              />
            </div>
            <div className="form-tour_group">
              <label>Loại tour</label>
              <select
                name="type"
                
                value={newTour.type}
                onChange={handleInputChange}
                className="form-tour_input"
                required
              >
                <option value="">Chọn loại tour</option>
                <option value="Tour trong nước">Tour trong nước</option>
                <option value="Tour quốc tế">Tour quốc tế</option>
              </select>
            </div>
          </div>
          <div className="form-tour_row">
            <div className="form-tour_group">
              <label>Tên tour</label>
              <input
                type="text"
                name="name"
                placeholder="Tên Tour"
                value={newTour.name}
                onChange={handleInputChange}
                className="form-tour_input"
                required
              />
            </div>
            <div className="form-tour_group">
              <label>Khu vực</label>
              <select
                name="area"
                value={newTour.area}
                onChange={handleInputChange}
                className="form-tour_input"
                required
              >
                <option value="">Chọn khu vực</option>
                <option value="Miền Bắc">Miền Bắc</option>
                <option value="Miền Trung">Miền Trung</option>
                <option value="Miền Nam">Miền Nam</option>
              </select>
            </div>
          </div>
          <div className="form-tour_row">
            <div className="form-tour_group">
              <label>Giá tour</label>
              <input
                type="number"
                name="price"
                placeholder="Giá Tour"
                value={newTour.price}
                onChange={handleInputChange}
                className="form-tour_input"
                required
              />
            </div>
            <div className="form-tour_group">
              <label>Ưu đãi</label>
              <input
                type="text"
                name="discount"
                placeholder="Ưu đãi"
                value={newTour.discount}
                onChange={handleInputChange}
                className="form-tour_input"
              />
            </div>
            <div className="form-tour_group">
              <label>Thành tiền</label>
              <input
                type="text"
                name="payment"
                placeholder="Thành tiền"
                value={newTour.paymentpayment}
                onChange={handleInputChange}
                className="form-tour_input"
              />
            </div>
          </div>
          <div className="form-tour_row">
          <div className="form-tour_group">
              <label>Phương tiện</label>
              <input
                type="text"
                name="vehicle"
                placeholder="Phương tiện"
                value={newTour.vehicle}
                onChange={handleInputChange}
                className="form-tour_input"
                required
              />
            </div>
            <div className="form-tour_group">
              <label>Giới hạn người</label>
              <input
                type="number"
                name="limit"
                placeholder="0"
                value={newTour.limit}
                onChange={handleInputChange}
                className="form-tour_input"
              />
            </div>
          </div>
          
          <div className="form-tour_group">
            <label>Mô tả</label>
            <input
              type="text"
              name="description"
              placeholder="Mô tả"
              value={newTour.description}
              onChange={handleInputChange}
              className="form-tour_textarea"
            />
          </div>
          <div className="form-tour_group">
            <label>Ảnh</label>
            <div className="image-upload">
              {newTour.image ? (
                <img src={newTour.image} alt="Tour" className="preview-image" />
              ) : (
                <div className="image-placeholder">
                  <span>Chọn ảnh</span>
                </div>
              )}
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="image-input"
              />
            </div>
          </div>
          <div className="form-tour_group">
            <label>Ghi chú nội bộ</label>
            <input
              type="text"
              name="note"
              placeholder="Ghi chú"
              value={newTour.note}
              onChange={handleInputChange}
              className="form-tour_input"
            />
          </div>
        </form>
        </div>
      </div>
    </div>
  );
};

export default AddTour;