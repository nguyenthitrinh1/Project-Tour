export default function StructureAnnoun(){
    return(
        <text>Announ</text>
    );
}