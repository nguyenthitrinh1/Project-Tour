import './index.css';
function Header(){
return(
<>
<div className="header">
<img  className="header-logo" src="/logo.png" alt="logo" />
</div>

</>
);
}
export default Header;