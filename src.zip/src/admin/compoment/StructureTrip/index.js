export default function StructureTrip(){
    return(
        <text>Announ</text>
    );
}