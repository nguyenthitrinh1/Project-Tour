import { NavLink } from 'react-router-dom';
import "./index.css";

export default function TabNavigation() {
  console.log('Rendering TabNavigation');
  return (
    <nav className='side-bar'>
      <NavLink to='main' className='tab'>
        {({ isActive }) => (
          <>
            <img
              src={isActive ? "/Pie-Chart 02.png" : "/Pie-Chart-02 (1).png"}
              alt="Main"
              className='tab-icon'
            />
          </>
        )}
      </NavLink>
      <NavLink to='tour' className='tab'>
        {({ isActive }) => (
          <>
            <img
              src={isActive ? "/Receipt Lines (1).png" : "/Receipt-Lines.png"}
              alt="Tour"
              className='tab-icon'
            />
          </>
        )}
      </NavLink>
      <NavLink to="trip" className="tab">
        {({ isActive }) => (
          <>
            <img
              src={isActive ? "/Bag 04 (1).png" : "/Bag-04.png"}
              alt="trip"
              className="tab-icon"
            />
          </>
        )}
      </NavLink>
      <NavLink to="announ" className="tab">
        {({ isActive }) => (
          <>
            <img
              src={isActive ? "/Hourglass 4.png" : "/Hourglass-03.png"}
              alt="announ"
              className='tab-icon'
            />
          </>
        )}
      </NavLink>
      <NavLink to='information' className="tab">
        {({ isActive }) => (
          <>
            <img
              src={isActive ? "/Users Profiles 3.png" : "/Users-Profiles-02.png"}
              alt="INFOR"
              className="tab-icon"
            />
          </>
        )}
      </NavLink>
      <NavLink to="setting" className="tab">
        {({ isActive }) => (
          <>
            <img
              src={isActive ? "/User-Profile-4.png" : "/User-Profile-03.png"}
              alt="setting"
              className='tab-icon'
            />
          </>
        )}
      </NavLink>
    </nav>
  );
}