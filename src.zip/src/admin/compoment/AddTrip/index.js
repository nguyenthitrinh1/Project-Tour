import React, { useState } from 'react';
import './AddTrip.css';

const Addtrip = ({ onClose, onAddtrip }) => {
  const [newtrip, setNewtrip] = useState({
    id: '',
    name: '',
    price: '',
    discount: '',
    vehicle: '',
    type: '',
    area: '',
    payment: '',
    description: '',
    image: '',
    note: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewtrip((prev) => ({ ...prev, [name]: value }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setNewtrip((prev) => ({ ...prev, image: imageUrl }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onAddtrip(newtrip);
  };

  return (
    <div className="modal-trip_overlay">
      <div className="modal-trip_content">
        <div className="modal-trip_header">
          <h5>Thiết lập trip</h5>
          <div className='modal-trip_header_group'>
          <img 
          src="/Eye Closed.png"
          alt=""
          />
          <div className='header-save'>
          <img 
          src="/Save 3.png"
          alt=""
          />
          <p>Lưu</p>
          </div>
          <button onClick={onClose} className="close-button">X</button>
          </div>
        </div>
        <div className="modal-trip_body">
        <form onSubmit={handleSubmit}>
          <div className="form-trip_row">
            <div className="form-trip_group">
              <label>Mã trip</label>
              <input
                type="text"
                name="id"
                placeholder='Mã trip'
                value={newtrip.id}
                onChange={handleInputChange}
                className="form-trip_input"
                required
              />
            </div>
            <div className="form-trip_group">
              <label>Loại trip</label>
              <select
                name="type"
                
                value={newtrip.type}
                onChange={handleInputChange}
                className="form-trip_input"
                required
              >
                <option value="">Chọn loại trip</option>
                <option value="trip trong nước">trip trong nước</option>
                <option value="trip quốc tế">trip quốc tế</option>
              </select>
            </div>
          </div>
          <div className="form-trip_row">
            <div className="form-trip_group">
              <label>Tên trip</label>
              <input
                type="text"
                name="name"
                placeholder="Tên trip"
                value={newtrip.name}
                onChange={handleInputChange}
                className="form-trip_input"
                required
              />
            </div>
            <div className="form-trip_group">
              <label>Khu vực</label>
              <select
                name="area"
                value={newtrip.area}
                onChange={handleInputChange}
                className="form-trip_input"
                required
              >
                <option value="">Chọn khu vực</option>
                <option value="Miền Bắc">Miền Bắc</option>
                <option value="Miền Trung">Miền Trung</option>
                <option value="Miền Nam">Miền Nam</option>
              </select>
            </div>
          </div>
          <div className="form-trip_row">
            <div className="form-trip_group">
              <label>Giá trip</label>
              <input
                type="number"
                name="price"
                placeholder="Giá trip"
                value={newtrip.price}
                onChange={handleInputChange}
                className="form-trip_input"
                required
              />
            </div>
            <div className="form-trip_group">
              <label>Ưu đãi</label>
              <input
                type="text"
                name="discount"
                placeholder="Ưu đãi"
                value={newtrip.discount}
                onChange={handleInputChange}
                className="form-trip_input"
              />
            </div>
            <div className="form-trip_group">
              <label>Thành tiền</label>
              <input
                type="text"
                name="payment"
                placeholder="Thành tiền"
                value={newtrip.paymentpayment}
                onChange={handleInputChange}
                className="form-trip_input"
              />
            </div>
          </div>
          <div className="form-trip_row">
          <div className="form-trip_group">
              <label>Phương tiện</label>
              <input
                type="text"
                name="vehicle"
                placeholder="Phương tiện"
                value={newtrip.vehicle}
                onChange={handleInputChange}
                className="form-trip_input"
                required
              />
            </div>
            <div className="form-trip_group">
              <label>Giới hạn người</label>
              <input
                type="number"
                name="limit"
                placeholder="0"
                value={newtrip.limit}
                onChange={handleInputChange}
                className="form-trip_input"
              />
            </div>
          </div>
          
          <div className="form-trip_group">
            <label>Mô tả</label>
            <input
              type="text"
              name="description"
              placeholder="Mô tả"
              value={newtrip.description}
              onChange={handleInputChange}
              className="form-trip_textarea"
            />
          </div>
          <div className="form-trip_group">
            <label>Ảnh</label>
            <div className="image-upload">
              {newtrip.image ? (
                <img src={newtrip.image} alt="trip" className="preview-image" />
              ) : (
                <div className="image-placeholder">
                  <span>Chọn ảnh</span>
                </div>
              )}
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="image-input"
              />
            </div>
          </div>
          <div className="form-trip_group">
            <label>Ghi chú nội bộ</label>
            <input
              type="text"
              name="note"
              placeholder="Ghi chú"
              value={newtrip.note}
              onChange={handleInputChange}
              className="form-trip_input"
            />
          </div>
        </form>
        </div>
      </div>
    </div>
  );
};

export default Addtrip;