export default function Information(){
    return(
        <text>Information</text>
    );
}