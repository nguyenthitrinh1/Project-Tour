export default function StructureInfor(){
    return(
        <text>Announ</text>
    );
}