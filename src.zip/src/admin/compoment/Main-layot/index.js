import React, { useState, useEffect } from "react";
import { Outlet, useLocation } from "react-router-dom";
import TabNavigation from "../Sidebar/index";
import "./MainLayout.css";

const MainLayout = () => {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState(location.pathname.split('/').pop());
  useEffect(() => {
    setActiveTab(location.pathname.split('/').pop());
  }, [location.pathname]);
  const tabConfig = {
    "main": { bgColor: "#D9D9D9", text: "Tổng quan" },
    "tour": { bgColor: "#D9D9D9", text: "Tour" },
    "trip": { bgColor: "#D9D9D9", text: "Trip" },
    "announ": { bgColor: "#ffffff", text: "Thông báo" },
    "information": { bgColor: "#ffffff", text: "Nhân viên" },
    "setting": { bgColor: "#ffffff", text: "Tài khoản" },
  };

  const { bgColor, text } = tabConfig[activeTab] || { bgColor: "#fff", text: "Chọn tab để xem nội dung" };

  return (
    <div className="Main-layout">
      <TabNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
      <div className="Main-header">{text}</div>
      <div className="Main-content" style={{ backgroundColor: bgColor }}>
        <Outlet />
      </div>
    </div>
  );
};

export default MainLayout;