import './index.css';
import React, { useState } from "react";
function Overview() {
    const [chuyenDi] = useState([
        {
            tour: "Hà Nội-SaPa 4 ngày 3 đêm",
            soLuongDi: 100,
            soLuongHuy: 5,
            doanhThu: 100000,
        },
        {
            tour: "Khám phá xứ sở kim chi 4 ngày 3 đêm",
            soLuongDi: 80,
            soLuongHuy: 10,
            doanhThu: 200000,
        },
    ]);

    const [nhanVien] = useState([
        {
            tenNhanVien: "Nguyễn Thị Trinh",
            soLuongTour: 5,
            doanhThu: 2000000,
            hoaHong: 100000,
        },
        {
            tenNhanVien: "Tôn Văn Diện",
            soLuongTour: 0,
            doanhThu: 0,
            hoaHong: 0,
        },
        {
            tenNhanVien: "Đỗ Mạnh Cường",
            soLuongTour: 0,
            doanhThu: 0,
            hoaHong: 0,
        },
    ]);
    return (
        <>
            <div className='Main-Overview'>
                <img className='Main-logo' src='/Frame-3.png' alt="" />
                <div className='Main_1'>
                    <div className='Main_1-1'>
                        <Card title="Tổng chuyến đi "
                            Total="500.000d"
                            Cout="1000" />
                        <Card title="Tổng chuyến hủy"
                            Total="500.000d"
                            Cout="1000" />
                    </div>
                </div>
                <div className='Main_2'>
                </div>
                <div className='Main_3'>
                <div className='Main_3-table'>
                    <div className='Main_3-content'>
                    <h3>Chuyến đi</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Thông tin tour</th>
                                <th>SL đã đi</th>
                                <th>SL hủy</th>
                                <th>Doanh thu</th>
                            </tr>
                        </thead>
                        <tbody>
                            {chuyenDi.map((item, index) => (
                                <tr key={index}>
                                    <td>{item.tour}</td>
                                    <td>{item.soLuongDi}</td>
                                    <td>{item.soLuongHuy}</td>
                                    <td>{item.doanhThu.toLocaleString()} đ</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                </div>
                {/* Bảng Nhân viên */}
                <div className='Main_3-table'>
                <div className='Main_3-content'>
                    <h3>Nhân viên</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Nhân viên</th>
                                <th>SL tour</th>
                                <th>Doanh thu</th>
                                <th>Hoa hồng</th>
                            </tr>
                        </thead>
                        <tbody>
                            {nhanVien.map((item, index) => (
                                <tr key={index}>
                                    <td>{item.tenNhanVien}</td>
                                    <td>{item.soLuongTour}</td>
                                    <td>{item.doanhThu.toLocaleString()} đ</td>
                                    <td>{item.hoaHong.toLocaleString()} đ</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                </div>
                </div>
            </div>
       
        </>
    );
}
const Card = ({ title, Total, Cout }) => (
    <div className="Main_1-1-card">
        <h4>{title}</h4>
        <div className="row">
            <span className="label">Tổng tiền</span>
            <span className="label">Số lượng</span>
        </div>
        <div className="row">
            <span className="value">{Total}</span>
            <span className="value">{Cout}</span>
        </div>
    </div>
);
// Dữ liệu mẫu cho bảng Chuyến đi

export default Overview;