import React from 'react';
import './SetTour.css';

const TripDetails = ({ trip, onClose }) => {
  if (!trip) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <div className="header-1">
            <div className="header-id">
              <span>12345</span>
              <img
                src="/Copy.png"
                alt=""
              />
              <p>Nguyễn Thị Trinh</p>
            </div>
            <div className='header-allot'>
              <span>Phân công cho</span>
              <img
                src="/Edit 2.png"
                alt=""
              />
              <p>Nguyễn Thị Trinh</p>
            </div>
          </div>
          <div className="header-1">
            <div className="header-status">
              <span>Trạng thái:</span>
              <span>Đang hoạt động</span>
            </div>
            <div className="header-print">
              <img src="/Icon.png" alt="" />
              <span>In</span>
            </div>
            <img
              src="Refresh Circle.png"
              alt="" />
            <button onClick={onClose} className="close-button">X</button>
          </div>
        </div>
        <div className="details-content">
          <div details-section-1>
            <div className="details-section">
              <h3>Chuyến đi</h3>
              <input 
              type="text"
              placeholder="Tìm kiếm tour"/>
              <div className="details-row-tour">
                <img src={trip.imageUrl || "https://via.placeholder.com/50"} alt="Tour" className="tour-image" />
                <div>
                  <p>{trip.name}</p>
                  <p>Người lớn: {trip.adultPrice?.toLocaleString()}đ × {trip.adultCount}</p>
                  <p>Trẻ nhỏ: {trip.childPrice?.toLocaleString()}đ × {trip.childCount}</p>
                </div>
              </div>
            </div>
            <div className="details-section-row">
            <div className="details-row">
              <h3>Thanh toán</h3>
              <div className="details-row-payment">
              <p>Tổng số tiền: {trip.totalAmount?.toLocaleString()}đ</p>
              <p>Phụ thu: {trip.surcharge?.toLocaleString()}đ</p>
              <p>Giảm giá: {trip.discount?.toLocaleString()}đ</p>
              <p>Sau giảm giá: {trip.finalAmount?.toLocaleString()}đ</p>
              <p>Cần thanh toán: {trip.amountDue?.toLocaleString()}đ</p>
              <p>Đã thanh toán: {trip.amountPaid?.toLocaleString()}đ</p>
              <p>Còn thiếu: {trip.remainingAmount?.toLocaleString()}đ</p>
              </div>
            </div>
            <div className="details-row">
              <h3>Ghi chú</h3>
              <textarea className="details-textarea" placeholder="Nhập ghi chú" defaultValue={trip.notes} />
            </div>
            </div>
          </div>
          <div details-section-2>
            <div className="details-section">
              <h3>Thông tin</h3>
              <div className="details-row">
                <label>Tạo lịch:</label>
                <input type="date" value={trip.createdDate} readOnly className="details-input" />
              </div>
              <div className="details-row">
                <label>Hướng dẫn viên:</label>
                <select value={trip.guideName} disabled className="details-input">
                  <option>{trip.guideName}</option>
                </select>
              </div>
              <div className="details-row">
                <label>Ngày khởi hành:</label>
                <input type="date" value={trip.startDate} readOnly className="details-input" />
              </div>
            </div>


            <div className="details-section">
              <h3>Khách hàng</h3>
              <div className="customer-info">
                <p>Tên khách hàng:{trip.customerName}</p>
                <p>Số điện thoại:{trip.customerPhone}</p>
                <p>Email:{trip.customerEmail}</p>
              </div>
              <div className="customer-info">
                <p>{trip.customerName}</p>
                <p>{trip.customerPhone}</p>
                <p>Điểm thưởng: {trip.rewardPoints}</p>
                <p>Thành công: {trip.successfulOrders}/{trip.totalOrders} đơn</p>
                <p>Chuyển đi cũ: {trip.transferHistory || "Chưa có lịch sử chuyển đi"}</p>
              </div>
            </div>
            <div className="details-section">
              <h3>Chuyển đi</h3>
              <p>Điểm đón: {trip.pickupLocation}</p>
              <p>Số lượng người: Người lớn: {trip.adultCount} | Trẻ nhỏ: {trip.childCount}</p>
              <p>Ngày kết thúc: {trip.endDate}</p>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default TripDetails;