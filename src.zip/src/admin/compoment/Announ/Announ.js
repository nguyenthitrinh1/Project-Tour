export default function Announ(){
    return(
        <text>Announ</text>
    );
}