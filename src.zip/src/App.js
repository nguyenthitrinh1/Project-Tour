import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import "./App.css";
import Login from './shared/compoment/Login';
import AdminDashboard from './admin/compoment/AdminDashboard';
import RouterCustom from './customer/compoment/router';

const ProtectedRoute = ({ children, allowedRole }) => {
  const role = localStorage.getItem('role')?.toLowerCase();
  console.log(`ProtectedRoute - role: ${role}, allowedRole: ${allowedRole}, time: ${new Date().toISOString()}`);
  if (!role || role !== allowedRole.toLowerCase()) {
    console.log('ProtectedRoute redirecting to /login');
    return <Navigate to="/login" />;
  }
  return children;
};

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/admin"
          element={
            <ProtectedRoute allowedRole="admin">
              <Navigate to="/admin/main" />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/*"
          element={
            <ProtectedRoute allowedRole="admin">
              <AdminDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/customer/*"
          element={
            <ProtectedRoute allowedRole="customer">
              <RouterCustom />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    </Router>
  );
};
export default App;