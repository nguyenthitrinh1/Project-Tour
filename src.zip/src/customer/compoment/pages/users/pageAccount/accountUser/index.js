import { memo, useState } from "react";
import "./au.scss";

const AccountUser = () => {
  const [showChangePassword, setShowChangePassword] = useState(false);

  const handleShowChangePassword = () => {
    setShowChangePassword(true);
  };

  const handleCloseChangePassword = () => {
    setShowChangePassword(false);
  };

  return (
    <div className="container-account">
      <h1 className="huygia">Hồ sơ của tôi</h1>
      <div className="content-info">
        <ul>
          <li>
            <span>Tên đăng nhập</span>
            <span>Cha eun woo</span>
          </li>
          <li>
            <span>Email</span>
            <span>Cew@gmail.com</span>
          </li>
          <li className="change-prior">
            <span>Mật khẩu</span>
            <span>123456789</span>
            <span onClick={handleShowChangePassword}>Thay đổi</span>
          </li>
          <li>
            <span>Căng cước công dân</span>
            <span>123456789</span>
          </li>
        </ul>
      </div>
      <button>Lưu</button>

      {showChangePassword && (
        <div className="change-password-form">
          <span className="close-button" onClick={handleCloseChangePassword}>
            &times;
          </span>
          <label>Mật khẩu mới:</label>
          <input type="password" />
          <label>Xác nhận mật khẩu:</label>
          <input type="password" />
          <button>Xác nhận</button>
        </div>
      )}
    </div>
  );
};

export default memo(AccountUser);