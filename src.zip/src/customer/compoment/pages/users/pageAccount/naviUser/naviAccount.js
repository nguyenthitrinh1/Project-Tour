import {memo} from "react"
import "./nu.scss"
import { User, Bell ,ReceiptText, LogOut } from "lucide-react";
import { NavLink} from "react-router-dom";

const PageAccountCommon = () => {
    return (
        <div className="container-account">
            <div className="info-account">
                <User/>
                <span>Cha eun woo</span>
            </div>
            <ul className="listNavi-account">
                <li>
                    <NavLink to="/customer/tai-khoan" className="linkto active">
                        <User/><span>Hồ sơ của tôi</span>
                    </NavLink>
                </li>
                <li>
                    <NavLink to="/customer/tai-khoan/thong-bao" className="linkto active">
                        <Bell/><span>Thông báo</span>
                    </NavLink>
                </li>
                <li>
                    <NavLink className="linkto active">
                        <ReceiptText/><span>Đơn mua</span>
                    </NavLink>
                </li>
                <li>
                    <NavLink className="linkto active">
                        <LogOut/><span>Đăng xuất</span>
                    </NavLink>
                </li>
            </ul>
        </div>
    );
}

export default memo(PageAccountCommon)