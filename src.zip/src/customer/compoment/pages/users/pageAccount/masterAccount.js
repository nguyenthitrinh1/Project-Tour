import { memo } from "react";
import NaviAcc from "../pageAccount/naviUser/naviAccount";
import "../pageAccount/accountUser/au.scss"
import { Outlet } from "react-router-dom";

const MasterAccount =  ({ ...props}) => {
    return (
        <div {...props} className="page-container">
            <div className="master-account">
                <div className="nav-section">
                    <NaviAcc />
                </div>
                <div className="content-section">
                    <Outlet />
                </div>
            </div>
        </div>
    )
};

export default memo(MasterAccount)