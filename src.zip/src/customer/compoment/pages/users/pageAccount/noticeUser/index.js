import { memo, useState, useEffect } from "react";
import "./noticeU.scss";
import myImage from "../../../../assets/img/tour.png";

const NoticeUser = () => {
  const [currentDateTime, setCurrentDateTime] = useState("");

  useEffect(() => {
    const now = new Date();
    const formattedDate = now.toLocaleDateString("vi-VN");
    const formattedTime = now.toLocaleTimeString("vi-VN", {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
    });
    setCurrentDateTime(`${formattedDate} ${formattedTime}`);
  }, []);

  const notices = [
    { title: "Tour sẽ bắt đầu vào ngày mai", description: "Hà nội - Sapa 4 Ngày 3 Đêm" },
    { title: "Tour sẽ bắt đầu vào ngày mai", description: "Hà nội - Sapa 4 Ngày 3 Đêm" },
    { title: "Tour sẽ bắt đầu vào ngày mai", description: "Hà nội - Sapa 4 Ngày 3 Đêm" },
    { title: "Tour sẽ bắt đầu vào ngày mai", description: "Hà nội - Sapa 4 Ngày 3 Đêm" },
  ];

  return (
    <div className="container-account">
      <div className="notices-list">
        {notices.map((notice, index) => (
          <div className="account-notice" key={index}>
            <div className="tittle-account-notice">
              <span>{notice.title}</span>
              <span>{currentDateTime}</span>
            </div>
            <div className="main-account-notice">
              <img src={myImage} alt="logo" />
              <span>{notice.description}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default memo(NoticeUser);