import { memo } from "react";
import myimg from "../../../assets/img/logomain.png";
import myimg1 from "../../../assets/img/pagemain.png";
import myimg2 from "../../../assets/img/dulich.png";
import "./style.scss"
import { ROUTERS } from "../../../utils/router";
import { Link } from "react-router-dom";
import { Clock, CarFront, CalendarCheck, Hotel,ShoppingCart ,MousePointerClick ,Sparkles} from 'lucide-react';
const HomePage =  () => {
    return (
      <div className="page-container">
        <div className="grid">
          { /* nút bấm */}
          <div className="homepage-img">
            <img src={myimg1} alt=""/>
          </div>
          <div className="button-switch">
            <button>
              <p>Tour trong nước</p>
            </button>
            <button>
              <p>Tour Ngoài nước</p>
            </button>
          </div>
          {/* Phần Tour Du Lịch */}
          <div className="tour-section">
            <h2>TOUR DU LỊCH</h2>
            <div className="grid-tour">
              {/* Lặp lại phần này cho mỗi tour */}
              <Link to={ROUTERS.USER.DETAILTOUR} className="linkto">
                <div className="tour-item">
                  <img src={myimg} alt="Tour Hà Nội Sapa 4 Ngày 3 Đêm" />
                  <h3>Hà Nội - Sapa 4 Ngày 3 Đêm</h3>
                  <div className="tour-details">
                    <div className="detail-1">
                      <div className="tour-icon_item">
                        <Clock />
                        <p>4 Ngày 3 đêm</p>
                      </div>
                      <div className="tour-icon_item">
                        <CalendarCheck/>
                        <p>Hàng tuần</p>
                      </div>
                      <div className="tour-icon_item">
                        <CarFront/>
                        <p>ô tô</p>
                      </div>
                      <div className="tour-icon_item">
                        <Hotel/>
                        <p>Khách sạn 5 sao</p>
                      </div>
                    </div>
                    <div className="detail-2"> 
                      <p className="new-price">4.390.000 VNĐ</p>
                    </div>
                    {/* Thêm thông tin chi tiết về tour nếu cần */}
                  </div>
                  <div className="view-detail">
                      <p>CHI TIẾT</p>
                  </div>
                </div>
              </Link>
              {/* Lặp lại cho các tour khác */}
            </div>
            <div className="view-more">
              <p>XEM THÊM TOUR</p>
            </div>
          </div>

          {/* Phần Các Tour Ưu Đãi Giảm Giá */}
            <div className="tour-section">
              <h2>Các Tour Ưu Đãi Giảm Giá</h2>
              <div className="grid-tour">
                {/* Lặp lại phần tử này cho mỗi tour ưu đãi */}
                <Link to={ROUTERS.USER.DETAILTOUR} className="linkto">
                  <div className="tour-item">
                    <img src={myimg} alt="Khám Phá Xứ Sở Kim Chi" />
                    <h3>Hà Nội - Sapa 4 Ngày 3 Đêm</h3>
                    <div className="tour-details">
                      <div className="detail-1">
                        <div className="tour-icon_item">
                          <Clock />
                          <p>4 Ngày 3 đêm</p>
                        </div>
                        <div className="tour-icon_item">
                          <CalendarCheck/>
                          <p>Hàng tuần</p>
                        </div>
                        <div className="tour-icon_item">
                          <CarFront/>
                          <p>ô tô</p>
                        </div>
                        <div className="tour-icon_item">
                          <Hotel/>
                          <p>Khách sạn 5 sao</p>
                        </div>
                      </div>
                      <div className="detail-2">
                        <p className="new-price">3.999.000 VNĐ</p> 
                        <p className="old-price">4.390.000 VNĐ</p>
                      </div>
                      {/* Thêm thông tin chi tiết về tour nếu cần */}
                    </div>
                      <div className="view-detail">
                        <p>CHI TIẾT</p>
                      </div>
                      <div className="home-product-item__sale">
                          <span className="home-product-item__sale-percent">40%</span>
                          <span className="home-product-item__sale-write">GIẢM</span>
                      </div>
                  </div>
                </Link>
                {/* Lặp lại cho các tour ưu đãi khác */}
              </div>
              <div className="view-more">
                <p>XEM THÊM TOUR</p>
              </div>
            </div>

          {/* Phần Cuộc Sống Cần Hãy Rời Đi Du Lịch */}
          <div className="banner-bottom">
            <img src={myimg2} alt=""/>
            {/* Thêm hình ảnh hoặc biểu tượng nếu cần */}
          </div>

          {/* Mấy cái thương hiệu uy tín */}
          <div className="why-are-us">
            <h1>TẠI SAO CHỌN TẬP ĐOÀN DCT TOUR</h1>
            <p>MIT-D TOUR với thông điệp mang đam mê của chúng tôi gửi gắm đến bạn qua những chuyến 
              đi và chất lượng luôn được đặt lên hàng đầu và mang đến cho du khách những sản phẩm hoàn hảo nhất</p>
          </div>
          <div className="near-footer">
            <div className="banner-reputation">
              <ShoppingCart />
              <div>
                <p>THANH TOÁN AN TOÀN</p>
                <p>Được bảo mật bởi tổ chức quốc tế</p>
              </div>
            </div>
            <div className="banner-reputation">
              <MousePointerClick />
              <div>
                <p>GIÁ TỐT - NHIỀU ƯU ĐÃI</p>
                <p>Ưu đãi và quà tặng hấp dẫn khi mua online</p>
              </div>
            </div>
            <div className="banner-reputation">
              <Sparkles />
              <div>
                <p>THƯƠNG HIỆU UY TÍN</p>
                <p>Thương hiệu lưu hành hàng đầu việt nam</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
};

export default memo(HomePage)