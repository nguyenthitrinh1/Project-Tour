import { memo, useState } from "react";
import "./style_detail.scss";
import img2 from "../../../assets/img/pagemain.png";
import { Link } from "react-router-dom";
import { ROUTERS } from "../../../utils/router";

const DetailTour = () => {
  console.log('chi tiet tour');
  const [mainImage, setMainImage] = useState(img2);
  const [activeTab, setActiveTab] = useState("description");
  
  // Sample images for demo - replace with your actual images
  const tourImages = [img2, img2, img2];
  
  // Sample content for tabs
  const tabContents = {
    description: {
      title: "Mô Tả Tour",
      content: "Hà Nội - Sapa 4 ngày 3 đêm là tour du lịch đưa bạn khám phá các địa điểm nổi tiếng của Sapa như bản Cát Cát, Fansipan, thung lũng Mường Hoa. Bạn sẽ được chiêm ngưỡng cảnh đẹp của ruộng bậc thang, tìm hiểu văn hóa của các dân tộc thiểu số và thưởng thức ẩm thực đặc sản vùng núi Tây Bắc."
    },
    itinerary: {
      title: "Lịch Trình Chi Tiết",
      content: "Ngày 1: Hà Nội - Sapa\nNgày 2: Bản Cát Cát - Fansipan\nNgày 3: Thung lũng Mường Hoa - Bản Tả Van\nNgày 4: Sapa - Hà Nội"
    },
    reviews: {
      title: "Đánh Giá Từ Khách Hàng",
      content: "★★★★★ Tour rất tuyệt vời, hướng dẫn viên nhiệt tình, cảnh đẹp ngoài mong đợi! - Nguyễn Văn A\n\n★★★★ Chuyến đi đáng nhớ với gia đình, thời tiết đẹp, dịch vụ tốt - Trần Thị B"
    }
  };

  // Handle image click
  const handleImageClick = (image) => {
    setMainImage(image);
  };
  
  // Handle tab click
  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div className="page-container">
      <div className="grid">
        <div className="homepage-img">
          <img src={img2} alt="" />
        </div>
        <div className="detail-trip">
          <div className="detail-1">
            <img src={mainImage} alt="Main tour image" className="img-parent" />
            <ul className="img-chld">
              {tourImages.map((image, index) => (
                <li 
                  key={index} 
                  className={mainImage === image ? 'active' : ''}
                  onClick={() => handleImageClick(image)}
                >
                  <img src={image} alt={`Tour image ${index + 1}`} />
                </li>
              ))}
            </ul>
          </div>
          <div className="detail-2">
            <h1>Hà nội - Sapa 4 Ngày 3 đêm</h1>
            <ul>
              <li>
                <span>Thời gian :</span>
                <span>4 ngày 3 đêm</span>
              </li>
              <li>
                <span>Phương tiện :</span>
                <span>Xe khách</span>
              </li>
              <li>
                <span>Lưu trú :</span>
                <span>Khách sạn 3 sao</span>
              </li>
              <li>
                <span>Khởi hành :</span>
                <span>Thứ 6 hàng tuần</span>
              </li>
            </ul>
            <div>
              <div>
                <span>Giá từ : </span>
                <span>2.500.000 vnd</span>
              </div>
              <Link to={`/customer/${ROUTERS.USER.BOOKING}`} className="linkto">
                <button>Đặt tour</button>
              </Link>
            </div>
          </div>
        </div>
        <div className="description-tip">
          <div className="button-describe">
            <button 
              className={activeTab === "description" ? "active" : ""}
              onClick={() => handleTabClick("description")}
            >
              Mô Tả
            </button>
            <button 
              className={activeTab === "itinerary" ? "active" : ""}
              onClick={() => handleTabClick("itinerary")}
            >
              Lịch Trình
            </button>
            <button 
              className={activeTab === "reviews" ? "active" : ""}
              onClick={() => handleTabClick("reviews")}
            >
              Đánh Giá
            </button>
          </div>
          <div className="space-content">
            {Object.keys(tabContents).map((tab) => (
              <div 
                key={tab} 
                className={`content-tab ${activeTab === tab ? "active" : ""}`}
              >
                <h3>{tabContents[tab].title}</h3>
                <p>{tabContents[tab].content}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default memo(DetailTour);