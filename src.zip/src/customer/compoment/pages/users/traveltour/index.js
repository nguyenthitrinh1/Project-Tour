import { memo, useState } from "react";
import Pagemain from "../../../assets/img/pagemain.png";
import myimg from "../../../assets/img/logomain.png";
import { ROUTERS } from "../../../utils/router";
import { Link } from "react-router-dom";
import { Clock, CarFront, CalendarCheck, Hotel } from 'lucide-react';
import "./tvtour.scss";

const TravelTour = () => {
  const [priceDropdown, setPriceDropdown] = useState(false);
  const [categoryDropdown, setCategoryDropdown] = useState(false);
  
  // Thêm nhiều tour hơn để kiểm tra phân trang
  const tourData = [
    { id: 1, title: "Hà Nội - Sapa 4 Ngày 3 Đêm", image: myimg, duration: "4 Ngày 3 đêm", schedule: "Hàng tuần", transport: "Ô tô", hotel: "Khách sạn 5 sao", price: "4.390.000 VNĐ" },
    { id: 2, title: "Đà Nẵng - Hội An 3 Ngày 2 Đêm", image: myimg, duration: "3 Ngày 2 đêm", schedule: "Hàng ngày", transport: "Ô tô", hotel: "Khách sạn 4 sao", price: "3.290.000 VNĐ" },
    { id: 3, title: "Phú Quốc 4 Ngày 3 Đêm", image: myimg, duration: "4 Ngày 3 đêm", schedule: "Hàng tuần", transport: "Máy bay", hotel: "Resort 5 sao", price: "6.490.000 VNĐ" },
    { id: 4, title: "Nha Trang 3 Ngày 2 Đêm", image: myimg, duration: "3 Ngày 2 đêm", schedule: "Thứ 6 hàng tuần", transport: "Ô tô", hotel: "Khách sạn 4 sao", price: "2.990.000 VNĐ" },
    { id: 5, title: "Hạ Long - Ninh Bình 2 Ngày 1 Đêm", image: myimg, duration: "2 Ngày 1 đêm", schedule: "Hàng ngày", transport: "Ô tô", hotel: "Khách sạn 4 sao", price: "1.890.000 VNĐ" },
    { id: 6, title: "Đà Lạt 3 Ngày 2 Đêm", image: myimg, duration: "3 Ngày 2 đêm", schedule: "Thứ 7 hàng tuần", transport: "Ô tô", hotel: "Khách sạn 3 sao", price: "2.490.000 VNĐ" },
    { id: 7, title: "Quy Nhơn 4 Ngày 3 Đêm", image: myimg, duration: "4 Ngày 3 đêm", schedule: "Hàng tuần", transport: "Ô tô", hotel: "Khách sạn 4 sao", price: "3.790.000 VNĐ" },
    { id: 8, title: "Huế - Hội An 5 Ngày 4 Đêm", image: myimg, duration: "5 Ngày 4 đêm", schedule: "Hàng tháng", transport: "Ô tô", hotel: "Khách sạn 5 sao", price: "5.290.000 VNĐ" },
    { id: 9, title: "Côn Đảo 3 Ngày 2 Đêm", image: myimg, duration: "3 Ngày 2 đêm", schedule: "Hàng tuần", transport: "Máy bay", hotel: "Resort 4 sao", price: "4.890.000 VNĐ" },
    { id: 10, title: "Hà Nội - Mộc Châu 2 Ngày 1 Đêm", image: myimg, duration: "2 Ngày 1 đêm", schedule: "Hàng ngày", transport: "Ô tô", hotel: "Khách sạn 3 sao", price: "1.590.000 VNĐ" },
    { id: 11, title: "Đà Nẵng - Huế 4 Ngày 3 Đêm", image: myimg, duration: "4 Ngày 3 đêm", schedule: "Hàng tuần", transport: "Ô tô", hotel: "Khách sạn 4 sao", price: "3.990.000 VNĐ" },
    { id: 12, title: "Sài Gòn - Cần Thơ 2 Ngày 1 Đêm", image: myimg, duration: "2 Ngày 1 đêm", schedule: "Hàng ngày", transport: "Ô tô", hotel: "Khách sạn 3 sao", price: "1.790.000 VNĐ" },
];
  
  // Cấu hình phân trang
  const toursPerPage = 4; // Giảm xuống 4 để dễ kiểm tra phân trang
  const totalPages = Math.ceil(tourData.length / toursPerPage);
  const [currentPage, setCurrentPage] = useState(1);
  
  // Lấy danh sách tour cho trang hiện tại
  const indexOfLastTour = currentPage * toursPerPage;
  const indexOfFirstTour = indexOfLastTour - toursPerPage;
  const currentTours = tourData.slice(indexOfFirstTour, indexOfLastTour);
  
  // Hàm chuyển trang
  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  
  // Hàm xử lý Previous và Next
  const handlePrevious = () => {
    if (currentPage > 1) setCurrentPage(currentPage - 1);
  };
  
  const handleNext = () => {
    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
  };

  // Tạo các nút số trang
  const renderPaginationButtons = () => {
    const maxVisibleButtons = 5; // Giới hạn số nút hiển thị
    let startPage = Math.max(1, currentPage - Math.floor(maxVisibleButtons / 2));
    const endPage = Math.min(totalPages, startPage + maxVisibleButtons - 1);
    
    if (endPage - startPage + 1 < maxVisibleButtons) {
      startPage = Math.max(1, endPage - maxVisibleButtons + 1);
    }
    
    const pages = [];
    for (let i = startPage; i <= endPage; i++) {
      pages.push(
        <button 
          key={i} 
          className={`pagination-button ${currentPage === i ? 'active' : ''}`}
          onClick={() => paginate(i)}
        >
          {i}
        </button>
      );
    }
    return pages;
  };

  return (
    <div className="page-container">
      <div className="grid">
        <div className="homepage-img">
          <img src={Pagemain} alt="Company Travel" />
        </div>
        <div className="more-tour">
          <div className="navi-seach">
            <h1>Tìm điểm đến của bạn</h1>
            <div className="search-input-group">
              <input type="text" placeholder="Nhập từ khóa" />
              <button type="button">Tìm kiếm</button>
            </div>
            <div className="dropdown">
              <button className="dropdown-toggle" onClick={() => setPriceDropdown(!priceDropdown)}>
                Tìm kiếm theo giá
              </button>
              {priceDropdown && (
                <div className="dropdown-menu">
                  <div className="dropdown-item">Từ thấp đến cao</div>
                  <div className="dropdown-item">Từ cao đến thấp</div>
                </div>
              )}
            </div>
            <div className="dropdown">
              <button className="dropdown-toggle" onClick={() => setCategoryDropdown(!categoryDropdown)}>
                Tìm kiếm theo danh mục
              </button>
              {categoryDropdown && (
                <div className="dropdown-menu">
                  <div className="dropdown-item">5 ngày 4 đêm</div>
                  <div className="dropdown-item">4 ngày 3 đêm</div>
                  <div className="dropdown-item">3 ngày 2 đêm</div>
                  <div className="dropdown-item">2 ngày 1 đêm</div>
                  <div className="dropdown-item">1 ngày</div>
                </div>
              )}
            </div>
            <button type="button">Tìm kiếm</button>
          </div>
          
          <div className="info-tour-render">
            <div className="grid-tour">
              {currentTours.map((tour) => (
                <Link key={tour.id} to={`/customer/${ROUTERS.USER.DETAILTOUR}`} className="linkto">
                  <div className="tour-item">
                    <img src={tour.image} alt={tour.title} />
                    <h3>{tour.title}</h3>
                    <div className="tour-details">
                      <div className="detail-1">
                        <div className="tour-icon_item"><Clock /><p>{tour.duration}</p></div>
                        <div className="tour-icon_item"><CalendarCheck /><p>{tour.schedule}</p></div>
                        <div className="tour-icon_item"><CarFront /><p>{tour.transport}</p></div>
                        <div className="tour-icon_item"><Hotel /><p>{tour.hotel}</p></div>
                      </div>
                      <div className="detail-2">
                        <p className="new-price">{tour.price}</p>
                      </div>
                    </div>
                    <div className="view-detail"><p>CHI TIẾT</p></div>
                  </div>
                </Link>
              ))}
            </div>
            
            {/* Phân trang với Previous và Next */}
            {totalPages > 1 && (
              <div className="pagination">
                <button 
                  className="pagination-button prev"
                  onClick={handlePrevious}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
                
                <div className="pagination-container">
                  <div className="pagination-numbers">
                    {renderPaginationButtons()}
                  </div>
                </div>
                
                <button 
                  className="pagination-button next"
                  onClick={handleNext}
                  disabled={currentPage === totalPages}
                >
                  Next
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default memo(TravelTour);