import {useState, useEffect,  } from "react";
import { Link } from "react-router-dom";
import { ROUTERS } from "../../../../utils/router";
import myImage from "../../../../assets/img/logomain.png";
import { FaRegUser, FaRegBell } from "react-icons/fa";
import { BsCart3 } from "react-icons/bs";
import { IoMenu } from "react-icons/io5";
import { HiOutlineXMark } from "react-icons/hi2";
import NotificationDropdown from "../header/noticeDropDown";

import "./style_header.scss";

// const useViewport = () => { 
//     const [width, setWidth] = useState(window.innerWidth);
  
//     useEffect(() => {
//       const handleWindowResize = () => setWidth(window.innerWidth);
//       window.addEventListener("resize", handleWindowResize);
//       return () => window.removeEventListener("resize", handleWindowResize);
//     }, []);
  
//     return { width };
//   };
  
const Header =  () => {
    const [notificationCount, setNotificationCount] = useState(99);
    const [isOpen, setIsOpen] = useState(false);
    const [showNotification, setShowNotification] = useState(false);

    const toggleNotificationDropdown = () => {
        setShowNotification(!showNotification);
    };
    // const [navbar, setNavbar] = useState([
    //     {
    //         name: "Trang chủ",
    //         path: ROUTERS.USERS.HOME,
    //     },
    //     {
    //         name: "Giới thiệu",
    //         path: ROUTERS.USERS.GIOITHIEU,
    //     },
    //     {
    //         name: "Tour du lịch",
    //         path: ROUTERS.USERS.HOME,
    //         isShowSubmenu: false,
    //         child: [
    //             {
    //                 name: "Trong nước",
    //                 path: "",
    //             },
    //             {
    //                 name: "Ngoài nước",
    //                 path: "",
    //             }
    //         ]
    //     },
    //     {
    //         name: "Dịch vụ",
    //         path: ROUTERS.USERS.HOME,
    //         isShowSubmenu: false,
    //         child: [
    //             {
    //                 name: "Tổ chức tour",
    //                 path: "",
    //             }
    //         ]
    //     },
    // ])
    const navItems = [
        {
            name: "TRANG CHỦ",
            path: ROUTERS.USER.HOME,
        },
        {
            name: "GIỚI THIỆU",
            path: ROUTERS.USER.GIOITHIEU,
        },
        {
            name: "TOUR DU LỊCH",
            path: ROUTERS.USER.TOURDULICH,
        },
        {
            name: "DỊCH VỤ",
            path: ROUTERS.USER.DICHVU,
        },
    ];
    
    return (
        <>
            <div className="header__top-fix">
                <div className="container">
                    <div className="logo">
                        <img className="logo_img" src={myImage} alt="logo" width={50} />
                    </div>
                    <ul className="navigation">
                        {navItems.map((item, index) => (
                                <li key={index}>
                                    <Link to={item.path} className="navigation_link active">
                                        {item.name}
                                    </Link>
                                </li>
                            ))}
                    </ul>
                    <div className="icon_Navigation">
                        <Link to={ROUTERS.USER.MASTERACC} className="linkto">
                            <div className="account">
                                <FaRegUser className="icon_navi"/>    
                            </div>
                        </Link>
                        <div className="cart">
                            <BsCart3 className="icon_navi"/>
                        </div>
                        <div className="notification">
                            <div onClick={toggleNotificationDropdown} className="notification_icon_wrap">
                                <FaRegBell className="icon_navi" />
                                {notificationCount > 0 && (
                                    <span className="notification_count">{notificationCount}</span>
                                )}
                            </div>
                            {showNotification && <NotificationDropdown />}
                        </div>

                        <div className="menu" onClick={() => setIsOpen(true)}>
                            <IoMenu className="icon_navi"/>
                        </div>
                    </div>    
                </div>  
            </div>
            {/* sildebar */}
            <div className={`sidebar ${isOpen ? "sidebar_open" : ""}`}>
                <div className="sidebar_content">
                    <HiOutlineXMark className="close_icon" onClick={() => setIsOpen(false)} />
                    <ul className="sidebar_navigation">
                    {navItems.map((item, index) => (
                            <li key={index}>
                                <Link 
                                    to={item.path} 
                                    className="navigation_link"
                                    onClick={() => setIsOpen(false)}
                                >
                                    {item.name}
                                </Link>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
            {/* Overlay background */}
            {isOpen && <div className="overlay" onClick={() => setIsOpen(false)} />}
        </>
    );
};

export default Header