import React from "react";
import { useState , useEffect} from "react";
import "./style_header.scss";
import myImage from "../../../../assets/img/tour.png"
// import DateTime from 'react-date-time';
const NotificationDropdown = () => {
    // const [notifications] = useState([
    //     { id: 1, content: "Bạn có tour mới được gợi ý." },
    //     { id: 2, content: "Đơn hàng của bạn đã được xác nhận." },
    //     { id: 3, content: "Có chương trình ưu đãi mới." },
    // ]);

    const [currentDateTime, setCurrentDateTime] = useState("");

    useEffect(() => {
      const now = new Date();
      const formattedDate = now.toLocaleDateString("vi-VN");
      const formattedTime = now.toLocaleTimeString("vi-VN", {
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
      });
      setCurrentDateTime(`${formattedDate} ${formattedTime}`);
    }, []);

    return (
        <div className="notification_dropdown">
            <h4>Thông báo</h4>
            {/* {notifications.length > 0 ? (
                <ul>
                    {notifications.map((item) => (
                        <li key={item.id}>{item.content}</li>
                    ))}
                </ul>
            ) : (
                <p>Không có thông báo nào</p>
            )} */}
             <div className="notification-content-container">
                <div className="content-notice">
                    <div className="tittle-notice">
                        <span>Tour sẽ bắt đầu vào ngày mai</span>
                        <span>{currentDateTime}</span>
                    </div>
                    <div className="main-notice">
                        <img src={myImage} alt="logo"/>
                        <span>Hà nội - Sapa 4 Ngày 3 Đêm</span>
                    </div>
                </div>
                <div className="content-notice">
                    <div className="tittle-notice">
                        <span>Tour sẽ bắt đầu vào ngày mai</span>
                        <span>{currentDateTime}</span>
                    </div>
                    <div className="main-notice">
                        <img src={myImage} alt="logo"/>
                        <span>Hà nội - Sapa 4 Ngày 3 Đêm</span>
                    </div>
                </div>
                <div className="content-notice">
                    <div className="tittle-notice">
                        <span>Tour sẽ bắt đầu vào ngày mai</span>
                        <span>{currentDateTime}</span>
                    </div>
                    <div className="main-notice">
                        <img src={myImage} alt="logo"/>
                        <span>Hà nội - Sapa 4 Ngày 3 Đêm</span>
                    </div>
                </div>
                <div className="content-notice">
                    <div className="tittle-notice">
                        <span>Tour sẽ bắt đầu vào ngày mai</span>
                        <span>{currentDateTime}</span>
                    </div>
                    <div className="main-notice">
                        <img src={myImage} alt="logo"/>
                        <span>Hà nội - Sapa 4 Ngày 3 Đêm</span>
                    </div>
                </div>
                
            </div>
            <div className="view_all">
                <a href="#">Xem tất cả</a>
            </div>
        </div>
    );
};

export default NotificationDropdown;
