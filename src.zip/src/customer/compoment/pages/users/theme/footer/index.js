import { memo } from "react";
import { Facebook, Instagram, Twitter, Mail, Phone } from "lucide-react";
import "./style_footer.scss"

const Footer =  () => {
    return (
        <footer>
            <div className="container">
                {/* Cột 1: Giới thiệu */}
                <div>
                    <h3>DCT TRAVEL GROUP</h3>
                    <p>04 Lệ Phi Vũ, P.Liễu Như Yên, Ninja, Đại Lục Tu Tiên Giới</p>
                    <p>Giấy phép đăng kí kinh doanh (Mã số thuế): 123456789 do Sở KHĐT TP Hà Nội cấp.</p>
                </div>

                {/* Cột 2: Liên kết nhanh */}
                <div>
                    <h3>CÁC CHI NHÁNH VĂN PHÒNG</h3>
                    <ul>
                        <li>
                            <h3>CHI NHÁNH TP.HCM</h3>
                            <p>55 Đỗ Quang Đẩu, P. Phạm Ngũ Lão, Quận 1, TP Hồ Chí Minh</p>
                        </li>
                        <li>
                            <h3>CHI NHÁNH TP.HÀ NỘI</h3>
                            <p>Số 22, 1/122 Phú Viên, Bồ Đề, Long Biên, Hà Nội</p>
                        </li>
                    </ul>
                </div>

                {/* Cột 3: Liên hệ */}
                <div className="contact-list">
                    <h3>Liên hệ</h3>
                    <ul>
                        <li>
                            <Mail size={20} className="icon" />
                            <a href="mailto:contact@example.com">dtc_hr@example.com</a>
                        </li>
                        <li>
                            <Phone size={20} className="icon" />
                            <span>+84 123 456 789</span>
                        </li>
                    </ul>
                    <div className="social-icons">
                        <a href="#"><Facebook size={24} /></a>
                        <a href="#"><Instagram size={24} /></a>
                        <a href="#"><Twitter size={24} /></a>
                    </div>
                </div>
            </div>

            {/* Bản quyền */}
            <div className="copyright">
                © 2024 Công ty Du Lịch. All rights reserved.
            </div>
        </footer>
    );
};

export default memo(Footer)