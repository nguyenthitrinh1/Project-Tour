import { memo, useState, useRef, useEffect } from "react";
import book from "../../../assets/img/booking.png";
import "../booking/style_book.scss";
import { User, TreePalm, FilePenLine, ReceiptText   } from "lucide-react";
const Booking = () => {
    
    const [regionDropdown, setRegionDropdown] = useState(false);
    const [selectedRegion, setSelectedRegion] = useState("");
    const regionRef = useRef(null);
  
    const regions = ["Miền Bắc", "Miền Trung", "Miền Nam"];
  
    const handleRegionClick = () => {
      setRegionDropdown(!regionDropdown);
    };
  
    const handleRegionSelect = (region) => {
      setSelectedRegion(region);
      setRegionDropdown(false);
    };
  
    useEffect(() => {
      const handleClickOutside = (event) => {
        if (regionRef.current && !regionRef.current.contains(event.target)) {
          setRegionDropdown(false);
        }
      };
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
        document.removeEventListener("mousedown", handleClickOutside);
      };
    }, [regionRef]);
    
    return (
        <div className="page-container">
            <div className="grid">
                <div className="homepage-img">
                    <img src={book} alt="Company Booking"/>
                </div>
                <div className="homepage-booking">
                    <div className="detail-book">
                        <div className="detail-book-1">
                            <div className="detail-book-1-1">
                                <div>
                                    <TreePalm/>
                                    <span>Đặt tour</span>
                                </div>
                                <div>
                                    <ul>
                                        <li><span>Loại tour</span><input type="text"/></li>
                                        <li><span>Số lượng người</span><input type="text"/></li>
                                        <li><span>Ngày khởi hành</span><input type="text"/></li>
                                    </ul>
                                    <ul>
                                        <li><span>Tên tour</span><input type="text"/></li>
                                        <li><span>Số trẻ em</span><input type="text"/></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="detail-book-1-2">
                                <div>
                                    <User/>
                                    <span>Thông tin khách hàng</span>
                                </div>
                                <div>
                                    <ul>
                                        <li><span>Họ và tên</span><input type="text"/></li>
                                        <li><span>Email</span><input type="text"/></li>
                                        <li ref={regionRef} className="region-dropdown">
                                                <text>Chọn vùng</text>
                                            <span onClick={handleRegionClick}>
                                                Khu vực {selectedRegion && `: ${selectedRegion}`}
                                            </span>
                                            {regionDropdown && (
                                                <ul className="region-list">
                                                {regions.map((region) => (
                                                    <li
                                                    key={region}
                                                    onClick={() => handleRegionSelect(region)}
                                                    >
                                                    {region}
                                                    </li>
                                                ))}
                                                </ul>
                                            )}
                                            </li>
                                    </ul>
                                    <ul>
                                        <li><span>Điện thoại</span><input type="text"/></li>
                                        <li><span>Căn cước công dan</span><input type="text"/></li>
                                        <li><span>Địa chỉ</span><input type="text"/></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div className="detail-book-2">
                            <div>
                                <FilePenLine />
                                <span>Thanh Toán</span>
                            </div>
                            <button> Thanh toán trực tuyến</button>
                        </div>
                    </div>
                    <div className="detail-info">
                        <div>
                            <ul>
                                <li><ReceiptText /><span>Thông tin đặt tour</span></li>
                                <li><span>Tên</span><span>Hà nội -sapa 4 ngày 3 đêm</span></li>
                            </ul>
                            <ul>
                                <li><span>Thời gian</span><span>MITD</span></li>
                                <li><span>Phương tiện</span><span>MITD</span></li>
                                <li><span>Lưu trú</span><span>MITD</span></li>
                                <li><span>Khởi hành</span><span>MITD</span></li>
                            </ul>
                        </div>
                        <div>
                            <ul>
                                <li><span>Tổng tiền</span><span>3.000.000</span></li>
                                <li><span>Thành tiền</span><span>4.000.000</span></li>
                            </ul>
                            <button>Thanh toán</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                
    );
}
export default memo(Booking)