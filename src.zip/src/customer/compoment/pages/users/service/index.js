import { memo, useState, useEffect,  } from "react";
import { Link } from "react-router-dom";
import { ROUTERS } from "../../../utils/router";
import Celebrate from "../../../assets/img/celebaratetour.png";
import Celebrateion from "../../../assets/img/img.png";
import "./style_service.scss";

const service =  () => {
    return (
        <div className="page-container">
            <div className="grid">
                <div className="homepage-img">
                    <img src={Celebrate} alt="Company Traval"/>
                </div>
                <Link to={`/customer/${ROUTERS.USER.DETAILSERVICE}`} className="linkto">
                    <div className="request-tour">
                        <div className="content-request">
                            <img src={Celebrateion} alt="Company Traval"/>
                            <h2>Tour theo yêu cầu</h2>
                        </div>
                    </div>
                </Link>
            </div>
        </div>
    );
};

export default memo(service)