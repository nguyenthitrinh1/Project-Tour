 // import { Component } from "react";
import { ROUTERS } from "./utils/router";
import HomePage from "./pages/users/homePage";
import {Routes, Route} from 'react-router-dom';

import MasterLayout from "./pages/users/theme/masterLayout";
import Introduce from "./pages/users/introduce";
import Service from "./pages/users/service";
import Traveltour from "./pages/users/traveltour";
import DetailTour from "./pages/users/detailTour";
import DetailService from "./pages/users/detailService";
import Booking from "./pages/users/booking";
import MasterAccount from "./pages/users/pageAccount/masterAccount";
import AccountUser from "./pages/users/pageAccount/accountUser/index";
import AccountNotice from "./pages/users/pageAccount/noticeUser/index";

const renderUserRouter = () => {
    console.log(" router");
    const userRouters = [
        {
            path: ROUTERS.USER.HOME,
            Component: <HomePage />,
        },
        {
            path: ROUTERS.USER.GIOITHIEU,
            Component: <Introduce />,
        },
        {
            path: ROUTERS.USER.DICHVU,
            Component: <Service />,
        },
        {
            path: ROUTERS.USER.TOURDULICH,
            Component: <Traveltour />,
        },
        {
            path: ROUTERS.USER.DETAILTOUR,
            Component: <DetailTour />,
        },
        {
            path: ROUTERS.USER.DETAILSERVICE,
            Component: <DetailService />,
        },
        {
            path: ROUTERS.USER.BOOKING,
            Component: <Booking />,
        },
    ]

    return  (
        <MasterLayout>  
            <Routes>
                {
                    userRouters.map((item, key) => (
                        <Route key={key} path={item.path} element={item.Component} />
                    ))
                }
                <Route path={ROUTERS.USER.MASTERACC} element={<MasterAccount />}>
                    <Route index element={<AccountUser />} />
                    <Route path="thong-bao" element={<AccountNotice />} />
                </Route>

            </Routes>
        </MasterLayout> 
    )
}

const RouterCustom = () => {
    return renderUserRouter();
}

export default RouterCustom;