export const ROUTERS = {
    USER: {
        HOME: "",
        GIOITHIEU: "gioi-thieu",
        TOURDULICH: "tour-du-lich",
        DICHVU: "dich-vu",
        DETAILTOUR : "chi-tiet-tour",
        DETAILSERVICE : "form-tour-yeu-cau",
        BOOKING : "dat-tour",
        
        MASTERACC : "tai-khoan",
        ACCO : "tai-khoan/thong-tin-tai-khoan",
        ACCOUNTNOTICE : "tai-khoan/thong-bao",
    }
}